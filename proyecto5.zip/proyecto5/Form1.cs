﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;

namespace proyecto5
{
    public partial class Form1 : Form
    {
        conexionsqln cn = new conexionsqln();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(cn.consql(textBox1.Text,textBox2.Text)==1)
            {
                MessageBox.Show("El usuario ha sido encontrado");
            }
            else
            {
                MessageBox.Show("El usuario no ha sido encontrado");

            }
        }
    }
}
